using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitFace : MonoBehaviour
{
    public MovementNew Hit;
    void Start()
    {
        
    }
    void Update()
    {

    }
    public void OnCollisionEnter2D(Collision2D other)
    {
        if (other.collider.tag == "Floor")
        {
            Hit.Mov = 0;
        }
    }
    public void OnCollisionExit2D(Collision2D other)
    {
        if (other.collider.tag == "Floor")
        {
            Hit.Mov = 10;
        }
    }
}
