using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColiderFloor : MonoBehaviour
{ 
    public MovementNew MovFis;

    void Start()
    {

    }
    void Update()
    {

    }
    public void OnCollisionStay2D(Collision2D other)
    {
        if (other.collider.tag == "Floor")
        {
            Debug.Log("XD");
            MovFis.floortouch = true;
        }
    }
    public void OnCollisionExit2D(Collision2D other)
    {
        if (other.collider.tag == "Floor")
        {
            Debug.Log("._.");
            MovFis.floortouch = false;
        }
    }
}