using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoFisica : MonoBehaviour
{
    SpriteRenderer SP;
    bool Idle;
    Animator Anim;
    float Mov;
    public float Grav;
    public float Vel;
    public float Jump;
    Rigidbody2D Jugador;
    public bool floortouch;
    public float VelMax;
    void Start()
    {
        //Llamo a los componentes
        Anim = GetComponent<Animator>();
        Jugador = GetComponent<Rigidbody2D>();
        SP = GetComponent<SpriteRenderer>();
    }


    void Update()
    {



        Mov = Input.GetAxisRaw("Horizontal");
            if(floortouch){
            if(Input.GetKey(KeyCode.Space)){
            //Jugador.AddForce(new Vector2(Mov,Jump)*Time.deltaTime*Vel);
            Jugador.velocity = new Vector2(Jugador.velocity.x,Jump);
                }
            }
        Jugador.AddForce(new Vector2(Mov,0f)*Time.deltaTime*Vel);
        if(Jugador.velocity.x >= VelMax){
            Jugador.velocity = new Vector2(VelMax,Jugador.velocity.y);
            //FIJARSE LA VELOCIDAD NEGATIVA !
        }


        //Animacion Idle
        if (Mov == 0)
        {
                Idle = true;
        }
        else
        {
            //Rotacion de personaje
            if (Mov > 0)
            {
                SP.flipX = false;
            }
            else
            {
                SP.flipX = true;
            }

            Idle = false;
        }
        Anim.SetBool("mov", !Idle);

        if (!floortouch)
        {
            Anim.SetBool("Jump", true);
        }
        else
        {
            Anim.SetBool("Jump", false);
        }


    }

}
