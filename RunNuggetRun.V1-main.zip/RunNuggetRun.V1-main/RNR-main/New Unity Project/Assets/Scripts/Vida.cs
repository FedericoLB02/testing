using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Vida : MonoBehaviour
{
    public Image Corazon;
    public Image CorazonKetchup;
    public int CantCorazon;
    public RectTransform PosicionPrimerCorazon;
    public Canvas MyCanvas;
    public int Offset;
    // Start is called before the first frame update
    void Start()
    {
        Transform PosicionCorazon = PosicionPrimerCorazon;
        for (int i = 0; i < CantCorazon; i++)
        {
            Image NewCorazon = Instantiate(Corazon, PosicionCorazon.position, Quaternion.identity);
            NewCorazon.transform.parent = MyCanvas.transform;
            PosicionCorazon.position = new Vector2(PosicionCorazon.position.x + Offset, PosicionCorazon.position.y);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(CantCorazon <= 0)
        {
            Destroy(gameObject);
            Destroy(Corazon);
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            Destroy(MyCanvas.transform.GetChild(CantCorazon + 1).gameObject);
            CantCorazon -= 1;
        }
        if(CantCorazon == 0)
        {
            NextLevel.instance.youLose();
        }
    }
}
