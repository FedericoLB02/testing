using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationBackground : MonoBehaviour
{

    void Start()
    {
        
    }

    void Update()
    {
        transform.position += Vector3.right*Time.deltaTime;
        if (transform.position.x >= 20f){
            transform.position = new Vector3(-31f, 0f, 0f);

        }
    }
}
