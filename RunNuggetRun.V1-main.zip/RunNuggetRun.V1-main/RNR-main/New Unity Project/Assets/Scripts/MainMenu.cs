using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenu : MonoBehaviour
{
    //Cierra el juego
    public void Exitgame()
    {
        Debug.Log("Exit");
        Application.Quit();
    }
}
