using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{
    public Button Level2Button, Level3Button;
    int LevelPassed;
    void Start()
    {
        LevelPassed = PlayerPrefs.GetInt("LevelPassed");
        Level2Button.interactable = false;
        Level3Button.interactable = false;

        switch (LevelPassed)
        {
            case 1:
                Level2Button.interactable = true;
                break;
            case 2:
                Level2Button.interactable = true;
                Level3Button.interactable = true;
                break;

        }
    }
    public void LevelToLoad(int Level)
    {
        SceneManager.LoadScene(Level);
    }

    public void resetPlayerPrefs()
    {
        Level2Button.interactable = false;
        Level3Button.interactable = false;
        PlayerPrefs.DeleteAll();
    }


}
