using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float Movement;
    void Start()
    {
        
    }

    void Update()
    {
        transform.Translate(new Vector3(Movement, 0f, 0f) * Time.deltaTime);
    }
    
}
