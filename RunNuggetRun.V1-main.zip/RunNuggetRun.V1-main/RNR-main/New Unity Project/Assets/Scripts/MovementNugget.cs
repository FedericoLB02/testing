using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementNugget : MonoBehaviour
{
    public  float runSpeed = 2f;
    public float jumSpeed = 3f;
    Rigidbody2D rb2D;

    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        rb2D.velocity = new Vector2(runSpeed, rb2D.velocity.y);
        if (Input.GetKeyDown(KeyCode.Space) && CheckGround.isGrounded)
        {
            rb2D.AddForce(new Vector2(0, jumSpeed * 50 * Time.fixedDeltaTime));
        }
        
    }

   





}
