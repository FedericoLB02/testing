using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementNew : MonoBehaviour
{
    [SerializeField] private LayerMask plataformLayerMask;
    public float Mov;
    SpriteRenderer SP;
    bool Idle;
    Animator Anim;
    public float Jump;
    Rigidbody2D Jugador;
    public bool floortouch;
    bool very;
    private BoxCollider2D boxCollider2d;
    
    void Start()
    {
        //Llamo a los componentes
        Anim = GetComponent<Animator>();
        Jugador = GetComponent<Rigidbody2D>();
        SP = GetComponent<SpriteRenderer>();
    }


    public void Update()
    {
            //Animacion Idle
            if (Mov == 0)
        {
            Idle = true;
        }
        else
        {
            Idle = false;
        }

        Anim.SetBool("mov", !Idle);
        //Animacion Salto
        if (!floortouch)
        {
            Anim.SetBool("Jump", true);
        }
        else
        {
            Anim.SetBool("Jump", false);
        }

    }

    private void FixedUpdate()
    { 
            if (Input.GetKeyDown(KeyCode.Space))
            {

                //Salto
                Jugador.AddForce(new Vector2(0, Jump * 50 * Time.fixedDeltaTime));

            }
            
        //Movimiento
        Jugador.velocity = new Vector2(Mov, Jugador.velocity.y);
        very = false;

    }

    
}
